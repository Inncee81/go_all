package main

import (
	//gin 路由目录夹
	_"./rou"
)
func main() {
	
}